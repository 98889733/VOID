package com.example.deleteme;

import android.app.Application;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Speaker.init(this); // прогреваем голос сразу при запуске
    }
}
