package com.example.deleteme;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {

    private static final String SECRET_CODE = "913#-5@2#-6047";
    private static final String PREFS = "orbit";
    private static final String KEY_UNLOCKED = "unlocked";

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Уже вводил пароль раньше — сразу чёрный экран при каждом входе
        SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_UNLOCKED, false)) {
            startActivity(new Intent(this, BlackActivity.class));
            finish();
            return;
        }

        web = new WebView(this);
        web.setBackgroundColor(0xFF07070D);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowContentAccess(false);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private class Bridge {
        @JavascriptInterface
        public boolean activate(String key) {
            if (key != null && SECRET_CODE.equals(key.trim())) {
                getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .edit().putBoolean(KEY_UNLOCKED, true).apply();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(MainActivity.this, BlackActivity.class));
                        finish();
                    }
                });
                return true;
            }
            return false;
        }
    }
}
