package com.example.deleteme;

import android.content.Context;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

/** Движок озвучки запускается заранее (при старте приложения), чтобы голос не опаздывал. */
public final class Speaker {

    private static TextToSpeech tts;
    private static boolean ready = false;
    private static String pending = null;

    private Speaker() {}

    public static synchronized void init(Context context) {
        if (tts != null) return;
        tts = new TextToSpeech(context.getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                synchronized (Speaker.class) {
                    if (status != TextToSpeech.SUCCESS || tts == null) return;
                    tts.setLanguage(new Locale("ru", "RU"));
                    ready = true;
                    if (pending != null) {
                        String p = pending;
                        pending = null;
                        tts.speak(p, TextToSpeech.QUEUE_FLUSH, null, "msg");
                    }
                }
            }
        });
    }

    public static synchronized void speak(Context context, String text) {
        init(context);
        if (ready && tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "msg");
        } else {
            pending = text; // скажет сразу, как только движок будет готов
        }
    }

    public static synchronized void stop() {
        pending = null;
        if (tts != null) tts.stop();
    }
}
