package com.example.deleteme;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.Locale;

public class BlackActivity extends Activity {

    private static final long WAIT_BEFORE_ASK_MS = 60_000;  // 1 минута
    private static final long REPEAT_ASK_MS = 5_000;        // повтор, если отказался
    private static final int REQ_UNINSTALL = 1;

    private static final String MESSAGE = "Удалите это приложение";
    private TextToSpeech tts;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable askUninstall = new Runnable() {
        @Override
        public void run() {
            requestSelfUninstall();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        TextView text = new TextView(this);
        text.setText(MESSAGE);
        text.setTextColor(Color.WHITE);
        text.setTextSize(30);
        text.setGravity(Gravity.CENTER);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        text.setPadding(pad, pad, pad, pad);

        root.addView(text, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // Закрыть можно касанием по экрану или кнопкой «Назад»
        root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });
        hideSystemBars();

        // Голос сам читает надпись
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS && tts != null) {
                    tts.setLanguage(new Locale("ru", "RU"));
                    tts.speak(MESSAGE, TextToSpeech.QUEUE_FLUSH, null, "msg");
                }
            }
        });

        // Через минуту просим хозяина телефона удалить приложение
        handler.postDelayed(askUninstall, WAIT_BEFORE_ASK_MS);
    }

    private void requestSelfUninstall() {
        if (isFinishing()) return;
        try {
            Intent i = new Intent(Intent.ACTION_DELETE);
            i.setData(Uri.parse("package:" + getPackageName()));
            i.putExtra(Intent.EXTRA_RETURN_RESULT, true);
            startActivityForResult(i, REQ_UNINSTALL);
        } catch (Exception e) {
            handler.postDelayed(askUninstall, REPEAT_ASK_MS);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Если мы всё ещё живы — человек отказался, спросим снова
        if (requestCode == REQ_UNINSTALL && !isFinishing()) {
            handler.postDelayed(askUninstall, REPEAT_ASK_MS);
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(askUninstall);
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onBackPressed() {
        goHome();
    }

    private void goHome() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(home);
        finishAndRemoveTask();
    }
}
