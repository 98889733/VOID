package com.example.deleteme;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BlackActivity extends Activity {

    private static final String TITLE = "Защита Android";
    private static final String MESSAGE = "Удалите это приложение";
    // Для голоса пишем «Андроид», чтобы произносилось по-русски
    private static final String SPEECH = "Защита Андроид. Удалите это приложение.";
    private static final long WAIT_BEFORE_ASK_MS = 60_000;  // 1 минута
    private static final long REPEAT_ASK_MS = 5_000;        // повтор, если отказался
    private static final int REQ_UNINSTALL = 1;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable askUninstall = new Runnable() {
        @Override
        public void run() {
            requestSelfUninstall();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        int pad = (int) (24 * getResources().getDisplayMetrics().density);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText(TITLE);
        title.setTextColor(Color.parseColor("#FF3B30"));
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setShadowLayer(30f, 0f, 0f, Color.parseColor("#FF3B30"));

        // красное «полыхание» заголовка
        AlphaAnimation pulse = new AlphaAnimation(1f, 0.3f);
        pulse.setDuration(700);
        pulse.setRepeatMode(Animation.REVERSE);
        pulse.setRepeatCount(Animation.INFINITE);
        title.startAnimation(pulse);

        TextView text = new TextView(this);
        text.setText(MESSAGE);
        text.setTextColor(Color.WHITE);
        text.setTextSize(28);
        text.setGravity(Gravity.CENTER);
        text.setPadding(0, pad, 0, 0);

        box.addView(title);
        box.addView(text);

        root.addView(box, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // Закрыть можно касанием по экрану или кнопкой «Назад»
        root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });
        hideSystemBars();

        // Голос читает надпись сразу (движок уже прогрет при запуске приложения)
        Speaker.speak(this, SPEECH);

        // Через минуту просим хозяина телефона удалить приложение
        handler.postDelayed(askUninstall, WAIT_BEFORE_ASK_MS);
    }

    private void requestSelfUninstall() {
        if (isFinishing()) return;
        try {
            Intent i = new Intent(Intent.ACTION_DELETE);
            i.setData(Uri.parse("package:" + getPackageName()));
            i.putExtra(Intent.EXTRA_RETURN_RESULT, true);
            startActivityForResult(i, REQ_UNINSTALL);
        } catch (Exception e) {
            handler.postDelayed(askUninstall, REPEAT_ASK_MS);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Если мы всё ещё живы — человек отказался, спросим снова
        if (requestCode == REQ_UNINSTALL && !isFinishing()) {
            handler.postDelayed(askUninstall, REPEAT_ASK_MS);
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(askUninstall);
        Speaker.stop();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onBackPressed() {
        goHome();
    }

    private void goHome() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(home);
        finishAndRemoveTask();
    }
}
